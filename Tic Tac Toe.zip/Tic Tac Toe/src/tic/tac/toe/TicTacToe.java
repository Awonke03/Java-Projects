/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tic.tac.toe;

/**
 *
 * @author Admin
 */
import java.util.*;
import javax.swing.JOptionPane;
public class TicTacToe {

    /**
     * @param args the command line arguments
     */
    
    public static  String [][]players = new String[2][2];
    public static String player;
    public static char [][] board =new char[3][3];
    
    public static void initilize()
    {
            char[] initial={'a','b','c','d','e','f','g','h','i'};
            int k=0;
            for(int i=0;i<3;i++)
            {
                for(int j=0;j<3;j++)
                {
                    
                    board[i][j]=initial[k];
                    k++;
                }
            }
            player=players[0][0];
            players[0][1]="O";
            players[1][1]="X";
            
            
    }
    public static void getboard()
    {
        String line;
        for(int i=0;i<3;i++)
            {
                line="";  
                for(int j=0;j<3;j++)
                {
                    line+=board[i][j]+"|";
                }
                System.out.println(line+"\n------");
            }
        
    }
    public static void playerswi()
    {
        if (player.equalsIgnoreCase(players[0][0]))
            player=players[1][0];
          else
            player=players[0][0];
    }
   public static boolean full()
   {
       char[] initial={'a','b','c','d','e','f','g','h','i'};
       for(int i=0;i<3;i++)
       {
           for(int j=0;j<3;j++)
           {
               for(int k=0;k<9;k++)
               {
                   if(board[i][j]==initial[k])
                   {
                       return false;
                   }
                   
               }
           }
       }
       return true;
   }
   public static boolean winner()
   {
       for(int i=0;i<3;i++)
       {
           if((board[i][0]==board[i][1]) && (board[i][0]==board[i][2]))
               return true;
           else
              if((board[0][i]==board[1][i]) && (board[0][i]==board[2][i]))
                  return true;
           else
                  if((board[0][0]==board[1][1]) && (board[2][2]==board[0][0]))
                      return true;
           else
                if((board[0][2]==board[1][1]) && (board[0][2]==board[2][0]))
                    return true;
                      
       }
       return false;
   }
   public static boolean errorcontrol(String input)
   {
       char[] initial={'a','b','c','d','e','f','g','h','i'};
       for(int k=0;k<9;k++)
           if(input.equalsIgnoreCase(String.valueOf(initial[k]))==true)
               return false;
       
       
       return true;
   }
    public static void play()
    { 
        Scanner get= new Scanner(System.in);
        String m;
        boolean g=false;
        System.out.println("Current Player: "+player);
        System.out.print("Enter box to play:");
        m=get.next();
        for(int i=0;i<3;i++)
            { 
                for(int j=0;j<3;j++)
                {
                   if(m.equalsIgnoreCase(String.valueOf(board[i][j]))==true)
                   {
                       g=true;
                        for(int k=0;k<2;k++)
                         {
          
                            if(player.equals(players[k][0])==true)
                            {
                            board[i][j]=players[k][1].charAt(0);
                            
                            }

                         }
                   }
                  
                }
                
               
                
            }
       
        if(full()==false && winner()==false && errorcontrol(m)==false)
        {
                 playerswi();
                 getboard();
                 play();
        }
             
        
        else
            if(winner()==true)
                System.out.println("Congradulations "+player+"\nYou have won the game");
        
                
       
   
        
      
        
        
        
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
       
        Scanner get= new Scanner(System.in);
        for(int i=0;i<2;i++)
        {
               System.out.print("Player "+(i+1)+" User Name:");
              players[i][0]=get.next();
        }   
        System.out.flush();
        initilize();
        getboard();
        play();
        
        
        
        
    }
    
}
